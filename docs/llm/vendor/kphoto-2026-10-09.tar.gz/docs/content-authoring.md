# Writing content

Everything the site shows lives under `content/`. The build validates all of
it and fails with file-scoped messages; the dev server shows the same
messages in the browser and reloads when you save.

## Posts — `content/blog/YYYY-MM-DD-name.md`

The file name is the law: `2026-03-22-good-morning.md` publishes at
`/blog/2026-03-22-good-morning/`. Names use lower-case letters, digits and
hyphens. Because the date is part of the URL, a title may repeat on a
different day — the URL stays unique.

```markdown
---
title: Good morning!
date: 2026-03-22
author: kphoto-team
summary: In which I say Good morning to you
tags:
  - introductions
---

## Good morning

It is almost eleven in the morning eastern time as I type this.
Hope you are doing well.
```

Rules the build enforces:

- `date` must be a real calendar date and must equal the file-name date
- `author` must match a file in `content/authors/`
- `summary` is required (it is shown in lists and in the feed)
- `tags` needs at least one entry; tags are shown on lists and detail pages
- unknown keys are rejected (catches typos like `sereis:`)
- optional `lang: es` marks a post not written in the default language; it
  then lives at `/es/blog/…`

### Scheduled publishing

The date does not just name the post — it **schedules** it
([ADR 0021](adr/0021-scheduled-publishing-and-daily-rebuild.md)). A post is
part of the site once its date has arrived in the site's time zone
(`America/New_York`, set in `src/lib/config.ts`); until then it is absent
from every page, the feed and the sitemap, and nothing links to it. You can
commit a whole run of future-dated posts at once and they will appear one by
one — a daily rebuild at 00:10/01:10 Eastern (plus every push) is what flips
each one live.

Future-dated posts are still **fully validated on every build**, so a typo in
next month's episode fails today, not at 1 a.m. on its publish date. To
preview scheduled posts locally, run the dev server with the cutoff disabled:

```bash
KPHOTO_SHOW_FUTURE=1 ./scripts/dev.sh
```

### Narration (optional)

Put the recording in `public/spoken/` and name it:

```yaml
narration: clean-hands-clean-food-en.wav
```

The post page then shows a native audio player and its card says "with
audio". A translation names its own recording, or has none. The file name
uses lower-case letters, digits and hyphens with `.wav`, `.mp3`, `.m4a`,
`.ogg`, `.opus`, `.flac` or `.webm`; a missing file fails the build
([ADR 0034](adr/0034-narration-audio.md)).

### Series (optional)

A post may belong to at most one series:

```yaml
series: TypeScript 7 in Practice
episode: 2
```

`episode` must be an integer ≥ 1, unique within the series, and requires
`series` (and vice versa). Series pages list episodes in ascending order;
posts in a series get previous/next navigation. Spell the series name
identically in every episode — conflicting spellings fail the build.

## Authors — `content/authors/author-id.yml`

The file name (lower-case letters, digits, hyphens) is the author id used in
post frontmatter and in the URL `/authors/author-id/`.

```yaml
name: Casey Rivers # required
email: casey@example.com # optional
bio: Writes about CSS. # optional
avatar: images/authors/x.svg # optional, path under public/
socials: # optional; github/bluesky/mastodon become links
  github: casey-rivers-kphoto
```

## Pages — `content/pages/name.md`

Standalone pages like About and Contact. Frontmatter is just `title:`; the
page publishes at `/name/`. Adding a page does **not** add it to the header —
navigation is deliberate, in `src/components/siteHeader.ts`.

## Translations

Write a post once; translate it only if you want to.

- Post: `content/blog/2026-03-22-good-morning.es.md` next to the original,
  published at `/es/blog/2026-03-22-good-morning/`.
- Page: `content/pages/about.es.md`, published at `/es/about/`.
- A post translation allows only `title` and `summary` (both required),
  optional `narration`, and the body; date, author, tags, series and episode
  come from the original.
  A page translation allows only `title`.
- The locale must be listed in `siteConfig.locales`. A translation without an
  original, or into the original's own language, fails the build.
- Untranslated posts still appear in every language's lists, marked with
  their language, linking to the original. Untranslated pages link to the
  original from the navigation.

## Markdown subset

Headings (`##`–`######`, with generated ids), paragraphs, `**bold**`,
`*emphasis*`, `` `code` ``, fenced code blocks with a language, links and
images (http, https, mailto and relative URLs only — anything else becomes
`#`), blockquotes (nestable), ordered/unordered/nested lists, horizontal
rules. Raw HTML is always escaped and shown as text, never executed.

## Ordering rules (everywhere)

- Lists of posts: newest first; same-day ties break by slug.
- Series pages: episode ascending.
- Tag and series indexes: alphabetical.
