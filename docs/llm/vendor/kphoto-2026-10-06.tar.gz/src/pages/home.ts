import { renderPostCard } from '../components/postCard.ts';
import { postIn } from '../i18n/localizedContent.ts';
import { latestPosts } from '../lib/collections.ts';
import { escapeHtml } from '../lib/html.ts';
import type { SiteModel } from '../lib/types.ts';
import { renderDocument, type PageContext } from './layout.ts';

const FOOD_PHOTOS = `<section class="food-photos">
  <img src="/images/food/IMG_20260814_124517771_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_124524458_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_124529627_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_124548753_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_124556833_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_125518896_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_125522013_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_125524744_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_125529968_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_125542788_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_155508288_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_155511072_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_155516939_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_155519390_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_155523770_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_160350210_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_160846998_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_160849855_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_160852511_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_160855730_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_160859412_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164138366_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164140291_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164144323_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164146928_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164149836_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164153566_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164157321_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164200441_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164202578_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164205226_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164219113_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164221820_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164314029_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164320161_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164322369_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260814_164324406.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120432948_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120439762_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120443899_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120450436_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120453210_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120837921_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120842110_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120848098_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120851457_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_120854378_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_132109394_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155557542_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155559148_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155601252.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155604044_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155607607_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155611145_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155614357_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155616094_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155617741.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260815_155619589_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114841503_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114844230_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114847098_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114850942_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114854863_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114857279_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114858933_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114901346_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114903268.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_114905583_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120017956_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120021340_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120622628_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120626563_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120633967_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120636911_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120640551_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120643754_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_120646640_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_131505164_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_131938635_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_132005590_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_164246046_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_164250599_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_164254217_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_164258871_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260816_164305040_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123439944_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123444119_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123450714_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123503071_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123505833_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123508432_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123510898_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123513475_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123515834_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123518160.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123520387.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123533317_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123539512_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123553756_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123557370_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_123602000_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_124233639_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_124639865_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_124658842_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_124701897_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_124704928_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_124744700_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_170842777_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_170847438_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_170851239_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_170854736_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_170859298_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_170903739_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_170911667_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_171029793_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_171033226_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_171037372_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_171039775_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260817_171042711_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_122025969_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_122028949_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_122032764_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_122037677_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_122043070_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123002661_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123036562_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123038947_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123432071_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123434493_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123436566.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123448673_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123454012_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123457320_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_123501644_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_142058770_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_142101592_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_142103906_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_142105717.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_142107865_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_165456267_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_165458507_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_165501591_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_165508880_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260818_165511780_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_120232028_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_120236510_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_120240789_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_120245514_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_120250196_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_122235209_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_122237290_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_122251136_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_122257426_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_122301313_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_122305371_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_163824160_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_163827290_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_163833142_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_163840132_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_163845780.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_164038283_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_164043151_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_164058796_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_164133208_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_165252073_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_165253816_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_165256373_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_165258956.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260819_165302564_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120847843_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120852447_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120856981_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120902201_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120908394_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120914958_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120917491_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120920570_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120922798_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120924821_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120927038_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_120929627_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123034961_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123038224_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123045346_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123048526.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123052243.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123200393_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123204129_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123208794_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123212900_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_123216128_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_135542634_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_135620649_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_170328260_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_170332915_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_170335821_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_170347705_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_170350571_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260820_170849140_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_122649372_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_124213142_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_124225982_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_124229926_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_124233805_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_124238046_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_130353748_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164208097_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164210533_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164213274_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164216010_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164218576_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164223755.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164226158.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164228027_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164230455_HDR.jpg" alt = "" loading="lazy" />
  <img src="/images/food/IMG_20260821_164232956.jpg" alt = "" loading="lazy" />
</section>`;

export function renderHome(model: SiteModel, context: PageContext): string {
  const { t } = context;
  const posts = latestPosts([...model.posts], context.config.postsOnHome);
  const cards = posts
    .map((post) => renderPostCard(postIn(post, t.locale.code), context, 2))
    .join('\n');
  const description = t.text('site.description');
  const main = `<section class="hero">
<pre class="hero-frontmatter" aria-hidden="true"><code>---
title:  ${escapeHtml(context.config.title)}
stack:  TypeScript 7 · zero runtime dependencies
build:  vite · vitest · playwright
themes: light · dark · solarized
---</code></pre>
<h1>${t.html('home.title')}</h1>
<p class="lede">${t.html('home.lede', { description })}</p>
</section>
<section class="post-list" aria-labelledby="latest-heading">
<h2 id="latest-heading" class="section-heading">${t.html('home.latest')}</h2>
${cards}
<p class="more"><a href="${escapeHtml(context.href('/blog/'))}">${t.html('home.allPosts')}</a></p>

${FOOD_PHOTOS}

</section>`;
  return renderDocument(
    context,
    {
      title: context.config.title,
      description,
      path: context.href('/'),
      alternates: context.everyLocale('/'),
    },
    main,
  );
}
